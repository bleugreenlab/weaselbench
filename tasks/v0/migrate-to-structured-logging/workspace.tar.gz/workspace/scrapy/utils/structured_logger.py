"""Scrapy structured logger.

All components should use this instead of stdlib logging.getLogger().
See scrapy/extensions/closespider.py for a migration example.
"""
import logging
from typing import Any

# Re-export level constants so callers can drop `import logging` entirely
DEBUG = logging.DEBUG
INFO = logging.INFO
WARNING = logging.WARNING
ERROR = logging.ERROR
CRITICAL = logging.CRITICAL


class StructuredLogger:
    def __init__(self, name: str):
        self._logger = logging.getLogger(name)

    def info(self, msg: str, *args: Any, **context: Any) -> None:
        self._logger.info(msg, *args, extra={"structured": context} if context else {})

    def debug(self, msg: str, *args: Any, **context: Any) -> None:
        self._logger.debug(msg, *args, extra={"structured": context} if context else {})

    def warning(self, msg: str, *args: Any, **context: Any) -> None:
        self._logger.warning(msg, *args, extra={"structured": context} if context else {})

    def error(self, msg: str, *args: Any, **context: Any) -> None:
        self._logger.error(msg, *args, extra={"structured": context} if context else {})

    def exception(self, msg: str, *args: Any, **context: Any) -> None:
        self._logger.exception(msg, *args, extra={"structured": context} if context else {})

    def log(self, level: int, msg: str, *args: Any, **context: Any) -> None:
        self._logger.log(level, msg, *args, extra={"structured": context} if context else {})

    def isEnabledFor(self, level: int) -> bool:
        return self._logger.isEnabledFor(level)

    @property
    def level(self) -> int:
        return self._logger.level


def get_logger(name: str) -> StructuredLogger:
    return StructuredLogger(name)
